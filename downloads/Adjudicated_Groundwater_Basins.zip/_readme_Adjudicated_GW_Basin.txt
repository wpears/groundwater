Department of Water Resources
Groundwater Information Center Interactive Map Application
Adjucated_GW_Basins

Readme.txt
 
Last revised: 10/29/2014

This document contains the following information:
   1) Download file type
   2) Description of data
   3) Geographic projection information
   3) Conditions of Use


****************************************************************************************

1) Download file type

Data downloads as .zip files.  To access the data, the dowloaded .zip files must first be unzipped.  

Most files downloaded from the GIC Interactive map application are ESRI shapefiles.  For more information about the use of ESRI shapefiles, see "http://help.arcgis.com/en/arcgisdesktop/10.0/help/index.html#//005600000002000000.htm" or "http://www.esri.com/library/whitepapers/pdfs/shapefile.pdf" 


****************************************************************************************

2) Description of data

This shapefile contains the boundaries of adjucated groundwater basins in California.

A form of groundwater management in California is through the courts.  When groundwater resources do not meet water demands in an area, landowners may turn to the courts to determine how much groundwater can be rightfully extracted by each overlying landowner or appropriator.  The court typically appoints a Watermaster to administer the judgment and to periodically report to the court.  As of 2013 there were 24 adjudicated groundwater basins in California, with the majority of the adjudications located in Southern California in the South Coast hydrologic region.  The majority of groundwater rights adjudications in California imposes extraction limits and/or initiates management actions in the event of declining groundwater levels or water quality degradation.  It should be noted that the primary objective of an adjudication is to provide a proportionate share of the available groundwater to the users within the basin so it can be extracted without having adverse effects to existing groundwater supplies.  Environmental concerns were not considered when most of the judgments were written.

These data were developed using the best available data for the California Water Plan Update 2013, however may contain errors. Formal metadata has not been prepared for this dataset.  Please refer to the conditions of use, below.


****************************************************************************************

3) Geographic projection information
	a) The data layers were originally prepared using ESRI ArcMap v.10.2.  The metadata for these files is being developed, and is currently limited.
	b) Downloaded shapefiles are provided in the WGS 1984 Web Mercator projection.  For more details, see "http://resources.arcgis.com/en/help/main/10.1/index.html#//003r00000001000000"

****************************************************************************************

4) Conditions of Use

All information provided by the Department of Water Resources on its Web pages and Internet sites, is made available to provide immediate access for the convenience of interested persons. While the Department believes the information to be reliable, human or mechanical error remains a possibility. Therefore, the Department does not guarantee the accuracy, completeness, timeliness, or correct sequencing of the information. Neither the Department of Water Resources nor any of the sources of the information shall be responsible for any errors or omissions, or for the use or results obtained from the use of this information. Other specific cautionary notices may be included on other Web pages maintained by the Department.


